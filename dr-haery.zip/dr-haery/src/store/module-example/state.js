export default function () {
  return {
    //
  }
}
