<template>
  <section class="gallery">
    <headerComponent
      title="گالری تصاویر"
      text="کامل ترین آرشیو تصاویر دندانپزشکی، زیبایی و بهداشت دهان"
      :img="header_bg"
      :routes="['صفجه اصلی']"
    />
    <section class="gallery-content">
      <div class="category-gallery">
        <h4 class="color-main">دسته بندی تصاویر</h4>
        <div class="category-gallery-btns revers">
          <router-link
            to="#"
            class="category-btn"
            v-for="(c, i) in category_imgs"
            :key="i"
            tag="button"
          >
            {{ c.text }}
            <img class="ml-2" :src="c.img" :alt="c.text" />
          </router-link>
        </div>
      </div>

      <section class="gallery-part">
        <h4 class="color-main">
          تصاویر مطب
          <img :src="category_imgs[0].img" :alt="category_imgs[0].text" />
        </h4>
        <div class="gallery-part-imgs">
          <img
            v-for="(part, i) in part_1"
            :key="i"
            :src="part.img"
            alt="gallery image"
          />
        </div>
        <router-link to="#" tag="p" class="more-img">
          <span class="revers">
            عکس های بیشتر از مطب
            <img src="../assets/Icons/Group 96.svg" alt="<"
          /></span>
        </router-link>
      </section>

      <section class="gallery-part">
        <h4 class="color-main">
          ایمپلنت
          <img :src="category_imgs[1].img" :alt="category_imgs[1].text" />
        </h4>
        <div class="gallery-part-imgs">
          <img
            v-for="(part, i) in part_2"
            :key="i"
            :src="part.img"
            alt="gallery image"
          />
        </div>
        <router-link to="#" tag="p" class="more-img">
          <span class="revers">
            عکس های بیشتر از ایمپلنت
            <img src="../assets/Icons/Group 96.svg" alt="<"
          /></span>
        </router-link>
      </section>

      <section class="gallery-part">
        <h4 class="color-main">
          اطفال
          <img :src="category_imgs[2].img" :alt="category_imgs[2].text" />
        </h4>
        <div class="gallery-part-imgs">
          <img
            v-for="(part, i) in part_3"
            :key="i"
            :src="part.img"
            alt="gallery image"
          />
        </div>
        <router-link to="#" tag="p" class="more-img">
          <span class="revers">
            عکس های بیشتر از اطفال
            <img src="../assets/Icons/Group 96.svg" alt="<"
          /></span>
        </router-link>
      </section>

      <section class="gallery-part">
        <h4 class="color-main">
          ترمیم و زیبایی
          <img :src="category_imgs[3].img" :alt="category_imgs[3].text" />
        </h4>
        <div class="gallery-part-imgs">
          <img
            v-for="(part, i) in part_4"
            :key="i"
            :src="part.img"
            alt="gallery image"
          />
        </div>
        <router-link to="#" tag="p" class="more-img">
          <span class="revers">
            عکس های بیشتر از ترمیم و زیبایی
            <img src="../assets/Icons/Group 96.svg" alt="<"
          /></span>
        </router-link>
      </section>
    </section>
  </section>
</template>

<script>
import headerComponent from "../components/header-component.vue";
import header_bg from "../assets/Photos/Mask Group 23@2x.png";
import galler_img from "../assets/Photos/tooth.jpg";
import icon_1 from "../assets/Icons/Group 23.svg";
import icon_2 from "../assets/Icons/Group 16.svg";
import icon_4 from "../assets/Icons/Group 465.svg";
import icon_7 from "../assets/Icons/Group 119.svg";

export default {
  name: "Gallery",
  components: { headerComponent },
  data() {
    return {
      header_bg,
      category_imgs: [
        { text: "تصاویر مطب", img: icon_7 },
        { text: "ایمپلنت", img: icon_1 },
        { text: "اطفال", img: icon_4 },
        { text: "ترمیم و زیبایی", img: icon_2 },
      ],
      part_1: [
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
      ],
      part_2: [
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
      ],
      part_3: [
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
      ],
      part_4: [
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
        { img: galler_img },
      ],
    };
  },
};
</script>

<style>
.gallery {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  width: 100%;
  overflow: hidden;
}

.gallery-content {
  z-index: 10;
  width: 70%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
}

.category-gallery {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: var(--white);
  border-radius: 15px;
  min-height: 120px;
  width: 100%;
  box-shadow: 0 5px 15px #aaa;
}
.category-gallery-btns {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}
.category-btn {
  border: none;
  border-radius: 50px;
  padding: 5px 25px;
  width: 23%;
  min-width: 100px;
  margin: 5px;
  background-color: var(--main-color);
  display: flex;
  justify-content: center;
  align-items: center;
  white-space: nowrap;
}

.category-btn > img {
  width: 20px;
  height: 20px;
}

.gallery-part {
  margin-top: 50px;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  box-sizing: border-box;
  padding: 10px;
}

.gallery-part > h4 > img {
  width: 60px;
  height: 60px;
}

.gallery-part-imgs {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
}

.gallery-part-imgs > img {
  width: 30%;
  height: auto;
  margin: 10px 0;
  border-radius: 10px;
}

.more-img {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  position: relative;
}

.more-img::before {
  content: "";
  width: 100%;
  height: 2px;
  background-color: var(--main-color);
  position: absolute;
}
.more-img span {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--white);
  z-index: 5;
  box-sizing: border-box;
  padding-right: 5px;
}
.more-img span img {
  width: 30px;
  height: 30px;
}

@media only screen and (max-width: 760px) {
  .gallery-part-imgs {
    flex-wrap: nowrap;
    scroll-snap-type: x mandatory;
    overflow-x: auto;
    justify-content: flex-start;
  }
  .gallery-part-imgs > img {
    flex-shrink: 0;
    scroll-snap-align: center;
    margin: 2px 10px;
    min-width: 150px;
  }
  .more-img {
    display: none;
  }
  .gallery-part > h4 {
    font-size: 1.5rem;
  }
}
</style>