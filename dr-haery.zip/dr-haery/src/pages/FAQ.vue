 <template>
  <div class="main-div blog">
    <headerComponent
      title="  پرسش و پاسخ"
      text="مجموعه ای از بهترین آرشیو مطالب دندانپزشکی، زیبایی و بهداشت دهان"
      :img="header_bg"
      :routes="['صفحه اصلی']"
    >
    </headerComponent>

    <div id="proboxmain" class="proboxmain">
      <div class="question">
        <h5>سوالات خود را بپرسید</h5>
      </div>
      <div class="main-three">
        <div class="botton-two">ارسال سوال</div>
      </div>
      <question
        text="لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است؟"
        v-for="n in 10"
        :key="n"
      />
      <div>
        <ul>
          <img src="~assets/icons/group 62.svg" alt="" />
          <ol>
            1
          </ol>
          <ol>
            2
          </ol>
          <ol>
            3
          </ol>
          <ol>
            4
          </ol>
          <ol>
            5
          </ol>
          <img src="~assets/icons/group 60.svg" alt="" />
        </ul>
      </div>

      <div class="main-two">
        <h6>آیا سوال دیگری دارید؟</h6>
      </div>
      <div class="input">
        <input type="text" class="input-one" name="نام" />
        <input type="text" class="input-one" name="ایمیل" />
      </div>
      <input type="text" class="input-two" name="دیدگاه" />
      <div class="main">
        <div class="botton">دیدگاه</div>
      </div>
    </div>
  </div>
</template>

<script>
import headerComponent from "../components/header-component.vue";
import question from "../components/question.vue";
import header_bg from "../assets/Photos/Mask Group 23@2x.png";

export default {
  name: "questionandanswer",
  components: { headerComponent, question },
  data() {
    return {
      header_bg,
    };
  },
};
</script>

<style>
.blog {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  overflow: hidden;
}

.proboxtitle,
.proboxcontent,
.proboxmain {
  position: relative;
}
.proboxtitle {
  width: 60%;
  border-radius: 20px;
  padding: 8px;
  cursor: pointer;
  border-style: solid;
  border-color: blueviolet;
}
.proboxcontent {
  width: 200px;
  height: auto;
  overflow: hidden;
  display: none;
  background-color: #f8f8f8;
  padding: 4px;
  direction: rtl;
}
.proboxmain {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;
  position: inherit;
  text-align: end;
  z-index: 10;
}
.svg {
  align-items: flex-end;
}
ol ol,
ol ul,
ul ol,
ul ul {
  margin-bottom: 0;
  display: flex;
  align-items: center;
}
dl,
ol,
ul {
  display: flex;
}
.input-one {
  width: 60%;
  border-radius: 20px;
  text-align: end;
  padding: 8px;
  border-style: solid;
  border-color: blueviolet;
}
.input {
  display: flex;
  width: 60%;
  margin-bottom: 4px;
  border-color: rgb(236, 229, 229);
}
.input-two {
  width: 60%;
  border-radius: 20px;
  text-align: end;
  padding: 8px;

  height: 100px;
  border-style: solid;
  border-color: blueviolet;
}
.p {
  display: flex;
  align-items: flex-end;
  justify-content: flex-end;
  align-content: center;
  flex-wrap: wrap;
  flex-direction: row;
  bottom: 0;
  margin-top: 10px;
}
.botton {
  border-radius: 20px;
  text-align: end;
  padding: 8px;
  cursor: pointer;
  border-style: solid;
  border-color: blueviolet;
}
.botton-two {
  display: none;
}

.main {
  width: 60%;
  height: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  position: inherit;
  margin-top: 10px;
  margin-bottom: 50px;
}
.main-two {
  width: 60%;
  height: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  position: inherit;
  margin-top: 10px;
  align-items: flex-end;
  margin-bottom: 20px;
}
.main-three {
  width: 40%;
  height: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  position: inherit;
  margin-top: 10px;
  text-align: center;
  align-items: center;
  margin-bottom: 20px;
  border-style: solid;
  border-color: blueviolet;
  border-radius: 20px;
  padding: 3px;
  display: none;
}
.svg {
  height: 40px;
  float: left;
}
.question {
  align-items: center;
  text-align: center;
  display: none;
}
.p {
  text-align: start;
}
@media only screen and (max-width: 760px) {
  ol ol,
  ol ul,
  ul ol,
  ul ul {
    display: none;
  }
  dl,
  ol,
  ul {
    display: none;
  }
  .input {
    display: none;
  }
  .input-one {
    display: none;
  }
  .input-two {
    display: none;
  }
  .main {
    display: none;
  }
  .botton {
    display: none;
  }
  .main-two {
    display: none;
  }
  .proboxmain {
    width: 85%;
  }
  .botton-two {
    border-radius: 20px;
    text-align: center;
    padding: 8px;
    cursor: pointer;
    border-style: solid;
    border-color: blueviolet;
    width: 60%;
    visibility: visible;
    display: contents;
  }
  .main-three {
    width: 40%;
    height: auto;
    display: flex;
    flex-direction: column;
    justify-content: space-evenly;
    position: inherit;
    margin-top: 10px;
    text-align: center;
    align-items: center;
    margin-bottom: 20px;
    border-style: solid;
    border-color: blueviolet;
    border-radius: 20px;
    padding: 3px;
  }
  .question {
    align-items: center;
    text-align: center;
    visibility: visible;
    display: contents;
  }
}
</style>


