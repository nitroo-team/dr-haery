<template>
  <section class="blog">
    <headerComponent
      title="مطالب دندان پزشکی"
      text="کامل ترین آرشیو مطالب دندانپزشکی، زیبایی و بهداشت دهان"
      :img="header_bg"
      :routes="['صفحه اصلی']"
    >
    </headerComponent>

    <section class="blog-content">
      <div class="blog-menu">
        <div class="blog-item m-2">
          <h5>دسته بندی مطالب</h5>
          <div class="category-items">
            <router-link
              v-for="(c, i) in categorys"
              :key="i"
              to="c.link"
              class="category-item"
              tag="p"
            >
              {{ c.text }}
              <i class="fa fa-angle-left mr-3 mb-1"></i>
            </router-link>
          </div>
        </div>

        <div class="blog-item m-2 super-seen">
          <h5>پربازدیدترین مطالب</h5>
          <div class="super-seen-items">
            <div
              v-for="(s, i) in super_seen"
              :key="i"
              class="super-seen-item revers"
            >
              <img :src="s.img" :alt="s.category" />
              <div class="super-seen-item-content m-2">
                <p class="d-flex revers mb-1">
                  <img
                    class="ml-1"
                    src="~assets/Icons/category.svg"
                    alt="category"
                  />
                  {{ s.category }}
                </p>
                <h6>
                  عنوان:‌
                  {{ s.title }}
                </h6>
              </div>
            </div>
          </div>
        </div>

        <div class="blog-item see-gallery m-2">
          <h5>در گالری ببینید</h5>
          <div class="seen-gallery">
            <img src="../assets/Photos/tooth.jpg" alt="tooth" />

            <div class="seen-gallery-content">
              <h6>ترمیم و زیبایی دندان</h6>
              <p>
                لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
                استفاده از طراحان
              </p>
            </div>

            <router-link
              to="/about-me"
              tag="button"
              class="botton botton-o revers seen-gallery-btn"
            >
              مشاهده بیشتر
              <i class="fa fa-angle-left mr-3 mb-1"></i>
            </router-link>
          </div>
        </div>
      </div>
      <div class="blog-cards">
        <Card :img="card_img" v-for="(n, i) in 8" :key="i" />
      </div>
    </section>
  </section>
</template>

<script>
import headerComponent from "../components/header-component.vue";
import Card from "../components/card.vue";
import header_bg from "../assets/Photos/Mask Group 23@2x.png";
import card_img from "../assets/Photos/tooth.jpg";
import super_seen_img from "../assets/Photos/tooth.jpg";

export default {
  name: "Blog",
  components: { headerComponent, Card },
  data() {
    return {
      header_bg,
      card_img,
      categorys: [
        { text: "جرمگیری", link: "#" },
        { text: "درمان ریشه", link: "#" },
        { text: "جراحی", link: "#" },
        { text: "زیبایی", link: "#" },
        { text: "کودکان", link: "#" },
        { text: "ایمپلنت", link: "#" },
      ],
      super_seen: [
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
      ],
    };
  },
};
</script>

<style>
.blog {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  overflow: hidden;
}

.blog-content {
  width: 100%;
  z-index: 10;
  display: flex;
  justify-content: center;
  align-items: flex-start;
}
.blog-menu {
  max-width: 300px;
  min-width: 250px;
  width: 50%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
}
.blog-item {
  width: 90%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-end;
  background-color: var(--main-color);
  border-radius: 10px;
  box-sizing: border-box;
  padding: 20px 30px;
  color: var(--white);
}
.blog-item h5 {
  width: 100%;
  text-align: right;
}
.category-items {
  width: 50%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
}

.category-item {
  width: 100%;
  text-align: right;
}

.super-seen {
  width: 90%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-end;
  background-color: var(--main-color);
  border-radius: 10px;
  box-sizing: border-box;
  padding: 20px 30px;
  color: var(--white);
}

.super-seen-items {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.super-seen-item {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 5px 0;
}

.super-seen-item > img,
.seen-gallery > img {
  width: 100px;
  height: auto;
  object-position: center;
  object-fit: cover;
  border-radius: 3px;
}

.super-seen-item-content {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-end;
}
.super-seen-item-content h6,
.super-seen-item-content p {
  margin: 0;
}

.super-seen-item-content p {
  font-size: 0.65rem;
  width: 100%;
  text-align: right;
}
.super-seen-item-content h6 {
  font-size: 0.65rem;
  width: 100%;
  text-align: right;
  line-height: normal;
}

.seen-gallery {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.seen-gallery > img {
  width: 100%;
  height: auto;
  border-radius: 10px;
}

.seen-gallery-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-end;
}

.seen-gallery-content h6,
.seen-gallery-content p {
  width: 100%;
  text-align: right;
}

.seen-gallery-btn {
  background-color: var(--white);
  border: none;
  color: var(--main-color-dark);
}

.blog-cards {
  max-width: 50%;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}

@media only screen and (max-width: 760px) {
  .blog-content {
    flex-direction: column;
    align-items: center;
  }
  .blog-menu {
    width: 100%;
  }
  .category-item {
    margin: 0;
  }
  .super-seen {
    width: 100%;
    margin: 0;
  }
  .super-seen-items {
    width: 100%;
    flex-direction: row;
    justify-content: flex-start;
    scroll-snap-type: x mandatory;
    overflow-x: auto;
  }

  .super-seen-item {
    flex-shrink: 0;
    scroll-snap-align: center;
    height: 100%;
    min-width: 180px;
    max-width: 250px;
    width: 80%;
  }

  .see-gallery {
    display: none;
  }
}
</style>