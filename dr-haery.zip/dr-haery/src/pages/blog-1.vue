<template>
  <div class="blog">
    <headerComponent
      title="آیا میتوان با وجود بارداری ارتوندسی کرد؟"
      :img="header_bg"
      :routes="['صفحه اصلی', 'مطالب دندان پزشکی']"
      :other="true"
    >
    </headerComponent>
    <div class="blog-content">
      <div class="blog-menu">
        <div class="blog-item m-2 super-seen">
          <h5>پربازدیدترین مطالب</h5>
          <div class="super-seen-items">
            <div
              v-for="(s, i) in super_seen"
              :key="i"
              class="super-seen-item revers"
            >
              <img :src="s.img" :alt="s.category" />
              <div class="super-seen-item-content m-2">
                <p class="d-flex revers mb-1">
                  <img
                    class="ml-1"
                    src="~assets/Icons/category.svg"
                    alt="category"
                  />
                  {{ s.category }}
                </p>
                <h6>
                  عنوان:‌
                  {{ s.title }}
                </h6>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="blog-content-main">
        <div class="main-card">
          <div :class="['cards m-2']">
            <img src="~assets/photos/doctor1.jpg" alt="dicotoe.hayedry" />
            <div class="cards-content">
              <div class="date-category revers">
                <p class="d-flex revers">
                  <img
                    class="ml-1"
                    src="~assets/Icons/category.svg"
                    alt="category"
                  />
                </p>
                <p class="d-flex revers">
                  <img
                    class="ml-1"
                    src="~assets/Icons/Icon material-access-time.svg"
                    alt="category"
                  />
                </p>
              </div>

              <h5>آیا میتوان با وجود بارداری ارتودنسی کرد؟</h5>
              <p>
                آیا در بارداری می توان ارتودنسی کرد؟ آیا با وجود یک بچه در شکم
                میتوان تحت درمان اصلاح فرم دندان ها قرار گرفت؟ آیا ارتودنسی در
                بارداری ضرر دارد؟ آیا ارتودنسی با بارداری تداخل دارد؟ عوارض و
                خطرات این درمان در حاملگی کدامند؟ جوانب مثبت این درمان چیست؟ آیا
                ارتودنسی در بارداری را میتوانم به بعد از زایمان موکول کنم؟ اصلا
                بهترین زمان انجام این درمان قبل از حاملگی ا ست یا حین و یا بعد
                از آن؟ اینها سوالاتی است که وبسایت کلینیک ایده آل با افتخار به
                آن ها پاسخ خواهد داد. خواندن این مقاله را از دست ندهید زیرا
                کاملتر از آن را در هیچ جای دیگری پیدا نخواهید کرد.
              </p>
              <h5>
                حین یا بعد از بارداری، بهترین دوره برای ارتودنسی کدام است؟
              </h5>
              <p>
                اینکه خانم های که در سنین بارداری قرار دارند چه وقت برای اصلاح
                مشکلات دندان های خود به متخصص ارتودنسی دندان مراجعه کنند همیشه
                یک چالش است. این خانم ها میتوانند از هر زمانی پیش، حین یا بعد از
                بارداری خود اقدام به درمان کنند. اما درمان ارتودنسی واقعا در
                کدام دوره بهتر است؟ پس ابتدا بگذارید انجام این درمان، قبل، حین و
                بعد از حاملگی را به صورت خلاصه بررسی کنیم.
              </p>
              <h5>قبل از بارداری</h5>
              <p>
                به نظر میرسد با توجه به اینکه خانم ها در این دوره از هر نظر آزاد
                تر هستند و دغدغه هایشان کمتر است، بهترین موقع انجام درمان، قبل
                از حامله شدن است. اگر برایتان مقدور باشد که قبل از اقدام به
                بارداری درمان خود را به اتمام برسانید خیلی خوب میشود. اما با این
                وجود اگر تحت درمان هستید و هنوز مدت درمان شما باقی مانده است
                نیز، فرصت خوبی برای بارداری و ادامه درمان است.
              </p>
              <h5>ارتودنسی در بارداری</h5>
              <p>
                خانم های زیادی وجود دارند که اتفاقا با آغاز حاملگی خود اقدام به
                انجام درمان ارتودنسی میکنند. با وجود برخی تغییرات گسترده طی این
                دوره که در بدن خانم ها ایجاد میشود، اما انجام این درمان حتی در
                این دوره هیچ محدودیتی به همراه ندارد.
              </p>
              <h5>بعد از بارداری</h5>
              <p>
                به دلیل اینکه درمانهای ارتودنسی نیازمند مراجعه زیاد به متخصصان و
                کلینیک هستند، مادر تا زمانی که فرزندش بزرگ نشود بهتر است که
                اقدام به درمان نکند. اگر کسی در خانه دارید که مراقب کودکتان باشد
                میتوانید طی جلسات ویزیت با خیال راحت به کلینیک بروید، اما اگر در
                نگهداری از فرزند خود تنها هستید انجام این درمان میتواند کمی
                دردسرساز شود.
              </p>
              <h5>ارتودنسی در بارداری با وجود لق شدن دندان ها</h5>
              <p>
                ما به لق شدن دندان ها در طی بارداری اشاره کردیم. دقت کنید که
                موضوع اصلی ما هم ارتودنسی در بارداری است. و لق بودن دندان چیزی
                نیست که متخصص ارتودنسی را مجاب کند برای شما درمانی ا نجام دهد.
                زیرا یک دندان لق میتواند با دستگاه های ارتودنسی ثابت بی افتد و
                حتی درمان را با شکست مواجه کند. اما خب، به این نکته هم باید
                اشاره کرد که همه خانم ها در این دوره، لق شدن دندان ها را تجربه
                نخواهند کرد. و یا حتی اکر تجربه کنند جزئی و موقتی است. با این
                وجود حتی اگر دندان های شما در این دوره لق نشده باشند نیز، باید
                مراقب باشید و به متخصص ارتودنسی خود بگویید تمام نکات و توصیه های
                لازم را به شما گوشزد کند. تا بهترین درمان ارتودنسی در دوران
                بارداری را داشته باشید. برای مثال به طور معمول بیماران عادی باید
                حداکثر پس از 8 هفته برای تنظیم مجدد سیم قوس دار و سایر بخش های
                بریس ارتودنسی به متخصص ارتودنسی مراجعه کنند. اما شما به عنوان یک
                خانم باردار باید طی همین مدت زمان چندین بار به متخصص خودتان
                مراجعه کنید
              </p>
              <h5>
                آیا ارتودنسی در بارداری نیازمند استفاده از پرتوی اشعه ایکس است؟
              </h5>
              <p>
                به عنوان یک خانم باردار، ممکن است شما در مورد اشعه ایکس ساطع شده
                برای گرفتن تصاویر پزشکی دندانهای خود نگران باشید. این یک نگرانی
                رایج و البته مهم در خصوص خانم های حامله است. همیشه بهتر است که
                در حین بارداری، از قرار گرفتن در معرض حتی مقادیر اندکی از اشعه
                ایکس جلوگیری کنید. با این حال، ارتودنتیست ها دست روی دست
                نمیگذراند تا اشعه به گردن، شکم و سایر بخش های بدن شما برخورد
                داشته باشد. آن ها از شیلدهای سربی یا محافظ اشعه برای پیشگیری از
                برخورد اشعه به شما و جنین استفاده میکنند. تا اطمینان حاصل شود که
                کودک در حال توسعه و رشد شما در معرض تابش پرتوهای ایکس نباشد .
                بنابراین با این تفاسیر ارتودنسی در دوران بارداری با همت متخصصان
                میتواند بی ضرر و عاری از صدمه اشعه باشد. با این وجود بهتر است که
                طی سه ماهه اول بارداری، از قرار گرفتن در معرض اشعه خودداری کنید.
                زیرا در این دوره حساس امکان جهش ژنتیکی در جنین وجود دارد و ممکن
                است با نقط ژنتیکی یا مادرزادی به دنیا بیاید.
              </p>
              <h5>
                آیا با وجود ارتودنسی در بارداری، رسیدگی به بهداشت دهان و دندان
                آسان است؟
              </h5>
              <p>
                یکی از مشکلات رایج ارتودنسی در میان اکثر بیماران، دشواری مسواک
                زدن، نخ دندان کشیدن و تمیز کردن دهان و دندان با وجود دستگاه های
                ارتودنسی مثل بریس ها است. به دلیل وجود این دستگاه ها شما مثل
                همیشه نمی‌توانید مسواک بزنید و مجبورید که وقت و دقت بیشتری برای
                این کار اختصاص دهید. این امر به بیماران عادی همیشه تاکید میشود
                اما تاکید بیشتر ما برای خانم های باردار است. زیرا مشکلاتی مانند
                تهوع و استفراغ را به کررات تجربه میکنند و تمیز کردن دهان و دندان
                یا رسیدگی به بهداشت دهان در این خصوص برایشان کمی دشوارتر از سایر
                بیماران میشود. با این حال اگر دستگاه های شما از نوع ارتودنسی
                متحرک باشد کمتر با این مساله روبرو خواهید شد
              </p>
              <h5>تاثیرات مخرب استفراغ روی بهداشت دهان و دندان</h5>
              <p>
                با هر بار استفراغ مقداری اسید همراه مواد بالا آورده شده وارد
                دهان شما میشود. این اسید میتواند به دندان های سالم شما لطمه بزند
                و اگر آن را مدیریت نکنید میتواند باعث پوسیدگی دندان های شما شود.
                در ثانی، اسید معده به اندازه ای قدرتمند هستد که خطری برای
                استحکام و موجودیت دستگاه های ارتودنسی باشند. اگر در دوران
                بارداری دچار استفراغ هستید، باید بلافاصله پس از استفراغ،
                دندانهای خود را بشویید و مسواک بزنید. اگر چنین نکنید و به شستشوی
                دندان های خود اهمیت ندهید ارتودنسی در دوران بارداری میتواند باعث
                پوسیدگی دندان های شما شود
              </p>
            </div>
          </div>
        </div>
        <div class="main-d">
          <div class="main-two">
            <h4>دیدگاه شما</h4>
          </div>
          <div class="questionaire-content">
            <div class="question-part-1">
              <input
                name="email"
                class="question-input"
                type="text"
                placeholder="ایمیل"
              />
              <input
                name="name"
                class="question-input"
                type="text"
                placeholder="نام"
              />
            </div>
            <textarea placeholder="سوال"></textarea>
            <button class="botton">ارسال سوال</button>
          </div>
        </div>
        <div class="main-opinion">
          <div class="opinion">
            <img src="~assets/icons/Icon awesome-user-circle.svg" class="svg" />
            <h6 class="h">علی</h6>
            <p class="p">
              لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
              استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله
              در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد
              نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
            </p>
            <div class="inline"><div></div></div>
            <img src="~assets/icons/Icon awesome-user-circle.svg" class="svg" />
            <h6 class="h">حسن</h6>
            <p class="p">
              لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با
              استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله
              در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد
              نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
            </p>
            <div class="inline"><div></div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import headerComponent from "../components/header-component.vue";
import header_bg from "../assets/Photos/Mask Group 23@2x.png";
import card_img from "../assets/Photos/tooth.jpg";
import super_seen_img from "../assets/Photos/tooth.jpg";

export default {
  name: "Blog",
  components: { headerComponent },
  data() {
    return {
      header_bg,
      card_img,
      super_seen: [
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
        {
          title: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
          link: "#",
          category: "دسته بندی",
          img: super_seen_img,
        },
      ],
    };
  },
};
</script>

<style scoped>
.questionaire-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  width: 100%;
  height: 100%;
}

.question-part-1 {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.question-input {
  width: 49%;
  border-radius: 20px;
  border: none;
  padding: 10px;
  padding-right: 20px;
  box-sizing: border-box;
  text-align: right;
  margin: 5px 0;
  border: 1px solid #666;
}

.questionaire-content > textarea {
  width: 100%;
  min-height: 250px;
  border-radius: 20px;
  flex-grow: 1;
  margin: 5px 0;
  padding: 10px;
  padding-right: 20px;
  box-sizing: border-box;
  text-align: right;
}

.blog-content-main {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.main-card {
  width: 100%;
  margin-top: 100px;
  display: contents;
}
.cards {
  width: 70%;
  height: 100%;
  border-radius: 20px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  background-color: #fff;
  box-shadow: 1px 10px 20px #666;
  color: #111;
}

.cards > img {
  width: 100%;
  height: auto;
  object-fit: cover;
  object-position: center;
  border-radius: 20px;
  z-index: 10;
}
.cards-content {
  width: 100%;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: flex-end;
  box-sizing: border-box;
  padding: 5px 20px;
}
.date-category {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.cards-content > h5,
.cards-content > p {
  width: 100%;
  text-align: right;
}
.cards-content h5 {
  font-size: 1.2rem;
  font-weight: 400;
}

.bg-color {
  background-color: var(--main-color);
  box-shadow: 0px 5px 5px #666;
  color: var(--white);
}
.input-one {
  width: 60%;
  border-radius: 20px;
  text-align: end;
  padding: 8px;
  border-style: solid;
  border-color: blueviolet;
}
.best {
  padding: 50px;
  width: 20%;
  height: 100%;
  display: flex;
  position: absolute;
  flex-direction: column;
  flex-wrap: nowrap;
  margin-left: 80px;
  background: blueviolet;
}

.input {
  display: flex;
  width: 60%;
  margin-bottom: 4px;
  border-color: rgb(236, 229, 229);
}
.input-two {
  width: 60%;
  border-radius: 20px;
  text-align: end;
  padding: 8px;
  height: 100px;
  border-style: solid;
  border-color: blueviolet;
}
.main {
  width: 60%;
  height: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  position: inherit;
  margin-top: 10px;
  margin-bottom: 50px;
}
.main-two {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  margin-bottom: 10px;
}
.botton {
  border-radius: 20px;
  text-align: end;
  padding: 8px;
  cursor: pointer;
  border-style: solid;
  border-color: blueviolet;
}
.main-d {
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  width: 70%;
  margin-top: 50px;
}

.opinion {
  padding: 10px;
  box-sizing: border-box;
  border-style: solid;
  width: 70%;
  border-radius: 10px;
}
.main-opinion {
  margin-top: 50px;
  margin-bottom: 50px;
  display: flex;
  justify-content: center;
  text-align: center;
  width: 100%;
}
.svg {
  float: right;
}
.h {
  text-align: end;
}
.p {
  text-align: end;
}
.inline {
  width: 100%;
  height: 5px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.inline > div {
  width: 60%;
  height: 100%;
  background-color: #111;
  border-radius: 10px;
}
.img {
  display: flex;
  width: 90px;
  position: absolute;
}
.div-one {
  display: flex;
  position: absolute;
  flex-direction: row-reverse;
}
.blog {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  overflow: hidden;
  display: flex;
}
.blog-content {
  width: 90%;
  z-index: 10;
  justify-content: center;
  align-items: flex-start;
  display: flex;
}
.blog-menu {
  max-width: 300px;
  min-width: 250px;
  width: 50%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
}
.blog-item {
  width: 90%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-end;
  background-color: var(--main-color);
  border-radius: 10px;
  box-sizing: border-box;
  padding: 20px 30px;
  color: var(--white);
}

.blog-item h5 {
  width: 100%;
  text-align: right;
}
.category-items {
  width: 50%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
}

.category-item {
  width: 100%;
  text-align: right;
}

.super-seen {
  width: 90%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-end;
  background-color: var(--main-color);
  border-radius: 10px;
  box-sizing: border-box;
  padding: 20px 30px;
  color: var(--white);
  position: sticky;
}

.super-seen-items {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.super-seen-item {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 5px 0;
}

.super-seen-item > img,
.seen-gallery > img {
  width: 100px;
  height: auto;
  object-position: center;
  object-fit: cover;
  border-radius: 3px;
}

.super-seen-item-content {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-end;
}
.super-seen-item-content h6,
.super-seen-item-content p {
  margin: 0;
}

.super-seen-item-content p {
  font-size: 0.65rem;
  width: 100%;
  text-align: right;
}
.super-seen-item-content h6 {
  font-size: 0.65rem;
  width: 100%;
  text-align: right;
  line-height: normal;
}

@media only screen and (max-width: 760px) {
  .questionaire-content {
    width: 100%;
  }
  .question-part-1 {
    flex-direction: column;
  }
  .question-input {
    width: 100%;
  }
  .questionaire-content > textarea {
    min-height: 200px;
  }

  .botton {
    border-radius: 20px;
    text-align: end;
    padding: 2px;
    cursor: pointer;
    border-style: solid;
    border-color: blueviolet;
    width: 60%;
  }
  .main-two {
    width: 60%;
    height: auto;
    display: flex;
    flex-direction: column;
    justify-content: space-evenly;
    position: inherit;
    margin-top: 10px;
    align-items: flex-end;
  }
  .blog-content {
    flex-direction: column;
    align-items: center;
  }
  .blog-menu {
    width: 100%;
  }
  .category-item {
    margin: 0;
  }
  .super-seen {
    width: 100%;
    margin: 0;
  }
  .super-seen-items {
    width: 100%;
    flex-direction: row;
    justify-content: flex-start;
    scroll-snap-type: x mandatory;
    overflow-x: auto;
  }

  .super-seen-item {
    flex-shrink: 0;
    scroll-snap-align: center;
    height: 100%;
    min-width: 180px;
    max-width: 250px;
    width: 80%;
  }

  .see-gallery {
    display: none;
  }
  .main-opinion {
    text-align: center;
    width: auto;
  }
  .main-d {
    text-align: center;
  }
}
</style>
