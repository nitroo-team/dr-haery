<template>
  <section class="home-page">
    <header class="home-page-header">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="60%"
        height="808.443"
        viewBox="350 -10 1097.186 808.443"
      >
        <path
          id="Path_209"
          data-name="Path 209"
          d="M821.058,109.944c-80.075-44.739-145.835-21.128-202.3,10.744-158.2,89.294-209.158,45.881-359.445,54.763C80.388,186.026,60.67,330.428,110.245,437.471c20.538,44.348,45.413,89.915,32.524,140.34C132.714,617.14,96.3,652.721,74,686.762-7.3,810.879,49.933,982.211,284.227,993.169c138.654,6.491,214.959-52.149,323.45-128.408,102.33-71.921,206.031-80.5,328.294-79.225,291.594,3.042,486.957-305.7,21.917-501.3C885.094,253.618,885.232,145.809,821.058,109.944Z"
          transform="translate(-39.137 -85.217)"
          fill="#a081cd"
        />
        <image href="~assets/photos/Group 2@2x.png" width="100%" height="98%" />
      </svg>
      <div class="home-page-header-content box-p">
        <h4 class="home-page-header-h4">سلام! من هانیه حائری هستم</h4>
        <h3 class="color-main home-page-header-h3 mt-2 mb-4">دندانپزشک</h3>
        <p class="home-page-header-p">
          جراح - دندانپزشک، فارغ التحصیل دکترای دندانپزشکی از دانشگاه آزاد
          اسلامی تهران با ۶ سال سابقه کار
        </p>
        <router-link to="/about-me" tag="button" class="botton">
          تماس با من
          <img
            class="ml-1"
            src="~assets/icons/icon awesome-phone-alt.svg"
            alt="phone"
          />
        </router-link>
      </div>
    </header>

    <section class="about-me revers box-p">
      <img src="~assets/photos/Group 499@2x.jpg" alt="Dr.Haery" />
      <div class="about-me-content">
        <h4>درباره من</h4>
        <p>
          لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده
          از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
          سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای
          متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه
          درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با
          نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان
          خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید
          داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به
          پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی
          سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
        </p>
        <router-link to="/about-me" tag="button" class="botton revers">
          ادامه
          <i class="fa fa-angle-left mr-3 mb-1"></i>
        </router-link>
      </div>
    </section>

    <section :class="['services box-p mt-5', slide_phone ? 'w-100' : '']">
      <h4 class="color-main">خدمات</h4>
      <h5>ارائه خدمات تخصصی دندانپزشکی با بهترین تجهیزات و بهترین کیفیت</h5>

      <div class="slider">
        <button class="next-btn" @click="nextSlide()">
          <img src="~assets/Icons/Group 60.svg" alt="next" />
        </button>
        <button class="prev-btn" @click="pervSlide()">
          <img src="~assets/Icons/Group 60.svg" alt="next" />
        </button>

        <div class="slider-items box-p">
          <div
            v-for="(slide, i) in sliders"
            :key="i"
            v-show="
              i === counter(index, +1) ||
              i === counter(index, -1) ||
              i === index
            "
            :class="[
              'slider-item',
              i === counter(index, +1)
                ? 'next-slide'
                : i === counter(index, -1)
                ? 'prev-slide'
                : 'main-slide',
            ]"
            @click="index = i"
          >
            <img :src="slide.icon" :alt="slide.text" />
            <p class="m-0">{{ slide.text }}</p>
          </div>
        </div>
      </div>
      <div class="slider-phone revers box-p">
        <div v-for="(slide, i) in sliders" :key="i" class="slider-item-phone">
          <img :src="slide.icon" :alt="slide.text" />
          <p class="m-0">{{ slide.text }}</p>
        </div>
      </div>
    </section>

    <section class="questions mt-5 box-p">
      <h4 class="color-main">سوالات متداول</h4>
      <p>مجموعه ای از بهترین آرشیو سوالات دندان پزشکی، زیبایی و بهداشت دهان</p>

      <div class="questions-content">
        <Question
          text="لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است؟"
        />
        <Question
          text="لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است؟"
        />
      </div>
      <div class="ask revers mt-3">
        <div class="any-ask revers">
          <h5 class="m-0 ml-2">آیا سوال دیگری دارید؟</h5>
          <button class="botton botton-o">سوال از من</button>
        </div>
        <router-link to="/about-me" tag="button" class="botton revers">
          سوالات بیشتر
          <i class="fa fa-angle-left mr-3 mb-1"></i>
        </router-link>
      </div>
    </section>

    <section class="gallery revers mt-5 box-p">
      <router-link to="/about-me" tag="button" class="botton revers btn-bottom">
        مشاهده تصاویر
        <i class="fa fa-angle-left mr-3 mb-1"></i>
      </router-link>
      <div class="imgs revers">
        <div class="imgs-up">
          <img src="~assets/Photos/tooth.jpg" alt="tooth" />
          <img src="~assets/Photos/tooth.jpg" alt="tooth" />
        </div>
        <div class="imgs-down">
          <img src="~assets/Photos/tooth.jpg" alt="tooth" />
          <img src="~assets/Photos/tooth.jpg" alt="tooth" />
        </div>
      </div>
      <div class="gallery-content">
        <h4 class="color-main">گالری</h4>
        <p>
          به گالری تصاویر سر بزنید تا تصاویر قبل و بعد انواع ارتودنسی‌ها، لمینت،
          ترمیم و زیبایی دندان، ایمپلنت دندان و سایر خدمات دندانپزشکی را دیده و
          با هم مقایسه کنید
        </p>
        <router-link to="/about-me" tag="button" class="botton revers">
          مشاهده تصاویر
          <i class="fa fa-angle-left mr-3 mb-1"></i>
        </router-link>
      </div>
    </section>

    <section class="last-subject revers mt-5">
      <div class="last-subject-content">
        <h4 class="color-main">اخرین مطالب</h4>
        <p>کامل ترین آرشیو مطالب دندانپزشکی، زیبایی و بهداشت دهان</p>
        <router-link to="/blog" tag="button" class="botton revers pos-bottom">
          سایر مطالب
          <i class="fa fa-angle-left mr-3 mb-1"></i>
        </router-link>
      </div>
      <div class="last-subject-cards">
        <Card :bg="true" :img="picture" link="/blog-1" />
        <Card :bg="true" :img="picture" link="/blog-1" />
      </div>
      <router-link to="/about-me" tag="button" class="botton revers btn-bottom">
        سایر مطالب
        <i class="fa fa-angle-left mr-3 mb-1"></i>
      </router-link>
    </section>

    <span class="mt-5"></span>
  </section>
</template>

<script>
import Question from "../components/question.vue";
import Card from "../components/card.vue";
import icon_1 from "../assets/Icons/Group 23.svg";
import icon_2 from "../assets/Icons/Group 16.svg";
import icon_3 from "../assets/Icons/Group 29.svg";
import icon_4 from "../assets/Icons/Group 465.svg";
import icon_5 from "../assets/Icons/Group 462.svg";
import icon_6 from "../assets/Icons/Group 464.svg";
import icon_7 from "../assets/Icons/Group 119.svg";
import picture from "../assets/Photos/tooth.jpg";

export default {
  name: "Homepage",
  components: { Question, Card },
  data() {
    return {
      picture,
      slide_phone: false,
      index: 0,
      sliders: [
        { text: "ایمپلنت", icon: icon_1 },
        { text: "زیبایی و ترمیم", icon: icon_2 },
        { text: "درمان ریشه", icon: icon_3 },
        { text: "کودکان", icon: icon_4 },
        { text: "پروتزهای ثابت و متحرک", icon: icon_5 },
        { text: "جراحی", icon: icon_6 },
        { text: "ارتودنسی", icon: icon_7 },
      ],
    };
  },
  methods: {
    counter(index, f, count = this.sliders.length) {
      index += f % count;
      if (index < 0) return count - 1;
      else if (index >= count) return index - count;
      return index;
    },
    nextSlide() {
      this.index = this.counter(this.index, +1);
    },
    pervSlide() {
      this.index = this.counter(this.index, -1);
    },
  },
};
</script>

<style>
.home-page {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  overflow-x: hidden;
}
.home-page-header {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
.home-page-header h3,
.home-page-header h4 {
  text-align: right;
}
.home-page-header-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-end;
}
.color-main {
  color: var(--main-color-dark);
}
.home-page-header-h3 {
  font-size: 5rem;
}
.home-page-header-h4 {
  font-size: 1.9rem;
  white-space: nowrap;
}
.home-page-header-p {
  text-align: right;
}

.about-me {
  display: flex;
  justify-content: center;
  align-items: center;
}

.about-me > img {
  width: 40%;
  height: auto;
}
.about-me-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  width: 40%;
  box-sizing: border-box;
  padding: 20px;
  margin-top: 50px;
}
.about-me-content h4 {
  text-align: right;
  width: 100%;
}

.about-me-content p {
  text-align: right;
}

.services {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-end;
}

.services h4,
.services h5 {
  width: 100%;
  text-align: right;
}
.slider {
  width: 100%;
  min-height: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  transform: scale(1.1);
}
.slider > button {
  position: absolute;
  top: 50%;
  border: none;
  background: none;
  outline: none;
}

.next-btn {
  right: -15%;
  transform: translateY(-50%);
}
.prev-btn {
  left: -15%;
  transform: translateY(-50%) rotateY(180deg);
}
.slider-items {
  flex-grow: 1;
  display: flex;
  justify-content: center;
  align-items: center;
}
.slider-item {
  background-color: var(--main-color);
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;
  width: 150px;
  height: 150px;
  border-radius: 10px;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  transition: 1s all ease-in-out;
}
.next-slide {
  left: 85%;
}
.prev-slide {
  left: 15%;
}
.main-slide {
  left: 50%;
  transform: translate(-50%, -50%) scale(1.3);
  z-index: 10;
}

.slider-item > img {
  width: 50%;
  height: 50%;
}
.slider-item > p {
  color: var(--white);
}

.slider-phone {
  width: 90%;
  min-height: 200px;
  display: none;
  justify-content: flex-start;
  align-items: center;
  scroll-snap-type: x mandatory;
  scroll-behavior: smooth;
  overflow-x: scroll;
  overflow-y: hidden;
}
.slider-item-phone {
  scroll-snap-align: start;
  flex-shrink: 0;
  background-color: var(--main-color);
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;
  width: 150px;
  height: 150px;
  border-radius: 10px;
  transition: 1s all ease-in-out;
  margin: 0 10px;
}

.questions {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.questions-content {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.questions h4,
.questions p {
  width: 100%;
  text-align: right;
}

.ask {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.any-ask {
  display: flex;
  justify-content: center;
  align-items: center;
}

.gallery {
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
}

.imgs {
  display: flex;
  justify-content: center;
  align-items: center;
}
.imgs img {
  width: 150px;
  height: 150px;
  object-fit: cover;
  object-position: center;
  margin: 10px;
  border-radius: 10px;
}

.imgs-down,
.imgs-up {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 400px;
}
.imgs-up {
  justify-content: flex-start;
}
.imgs-down {
  justify-content: flex-end;
}

.gallery-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  box-sizing: border-box;
  padding: 10px;
  width: 40%;
}
.gallery-content h4,
.gallery-content p {
  width: 100%;
  text-align: right;
}

.last-subject {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  position: relative;
}

.last-subject-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
}

.last-subject-content h4,
.last-subject-content p {
  width: 100%;
  text-align: right;
}

.last-subject-cards {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}

.btn-bottom {
  display: none;
}

@media only screen and (max-width: 760px) {
  .home-page-header {
    margin-top: 130px;
  }
  .home-page-header > svg {
    display: none;
  }
  .home-page-header-content {
    align-items: center;
  }
  .home-page-header-p {
    text-align: center;
  }

  .about-me {
    flex-direction: column;
  }

  .about-me > img {
    width: 90%;
    height: auto;
  }
  .about-me-content {
    margin: 0;
    align-items: center;
    width: 90%;
    padding: 0;
  }
  .about-me-content h4 {
    text-align: center;
  }

  .about-me-content p {
    text-align: center;
  }

  .services h4,
  .services h5 {
    text-align: center;
  }

  .questions h4,
  .questions h5 {
    text-align: center;
  }

  .ask {
    flex-direction: column-reverse;
  }
  .any-ask {
    flex-direction: column;
    margin-top: 20px;
  }

  .gallery {
    flex-direction: column-reverse;
    justify-content: flex-end;
  }
  .imgs img {
    width: 120px;
    height: 120px;
    margin: 5px;
  }

  .imgs-down,
  .imgs-up {
    min-height: 300px;
  }
  .gallery-content {
    padding: 0;
    align-items: center;
    width: 100%;
  }

  .gallery-content h4,
  .gallery-content p {
    text-align: center;
  }
  .gallery-content > .botton {
    display: none;
  }
  .btn-bottom {
    margin-top: 10px;
    display: flex;
  }

  .last-subject {
    flex-direction: column;
    align-items: center;
  }

  .last-subject-content h4,
  .last-subject-content p {
    text-align: center;
  }
  .last-subject-content > .botton {
    display: none;
  }
  .slider{
    display: none;
  }
  .slider-phone{
    display: flex;
  }
}
</style>