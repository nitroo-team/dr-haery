<template>
  <section class="aboutme">
      <headerComponent
      title="درباره من"
      :img="header_bg"
      :routes="['صفحه اصلی']"
    >
    </headerComponent>
    <section class="about-me revers box-p">
      <img src="~assets/photos/Group 499@2x.jpg" alt="Dr.Haery" />
      <div class="about-me-content">
        <h4 class="h4"> من هانیه حائری هستم</h4>
        <h5 class="h5">جراح -دندان پزشک-فارغ التحصیل دکترای دندان پزشکی از دانشگاه آزاد اسلامی با بیش از 6 سال سابقه</h5>
        <p>
          لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده
          از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
          سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای
          متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه
          درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با
          نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان
          خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید
          داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به
          پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی
          سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
        </p>
      </div>
    </section>
    <section class="about-me revers box-p">
        <div class="about-me-content">
        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
        ، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط
         فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باش
        د، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان
         را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص ط
        راحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید دا
        شت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و 
        زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته 
        اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
        ، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط
         فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باش
        د، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان
         را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص ط
        راحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید دا
        شت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و 
        زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته 
        اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
        ، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط
         فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باش
        د، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان
         را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص ط
        راحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید دا
        شت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و 
        زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته 
        اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
        ، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط
         فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باش
        د، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان
         را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص ط
        راحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید دا
        شت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و 
        زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته 
        اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
        ، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط
         فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باش
        د، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان
         را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص ط
        راحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید دا
        شت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و 
        زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته 
        اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
        ، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط
         فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باش
        د، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان
         را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص ط
        راحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید دا
        شت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و 
        زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی، و جوابگوی سوالات پیوسته 
        اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.
        </div>
    </section>
  </section>
</template>
<script>
import headerComponent from "../components/header-component.vue";
import header_bg from "../assets/Photos/Mask Group 23@2x.png";
export default {
  name: "questionandanswer",
  components: { headerComponent },
  data() {
    return {
      header_bg
    };
  }
};
</script>
<style scoped>
.aboutme {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  overflow-x: hidden;
}
.home-page-header {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
.home-page-header h3,
.home-page-header h4 {
  text-align: right;
}
.home-page-header-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-end;
}
.color-main {
  color: var(--main-color-dark);
}
.home-page-header-h3 {
  font-size: 5rem;
}
.home-page-header-h4 {
  font-size: 1.9rem;
  white-space: nowrap;
}
.home-page-header-p {
  text-align: right;
}

.about-me {
  display: flex;
  justify-content: center;
  align-items: center;
}

.about-me > img {
  width: 40%;
  height: auto;
}
.about-me-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  width: 40%;
  box-sizing: border-box;
  padding: 20px;
  margin-top: 50px;
  text-align: end;
}
.about-me-content h4 {
  text-align: right;
  width: 100%;
}

.about-me-content p {
  text-align: right;
}
.h5{
    text-align: end;
}
h4{
  color: blueviolet;
}
@media only screen and (max-width: 760px) {
  .home-page-header {
    margin-top: 130px;
  }
  .home-page-header > svg {
    display: none;
  }
  .home-page-header-content {
    align-items: center;
  }
  .home-page-header-p {
    text-align: center;
  }

  .about-me {
    flex-direction: column;
  }

  .about-me > img {
    width: 90%;
    height: auto;
  }
  .about-me-content {
    margin: 0;
    align-items: center;
    width: 90%;
    padding: 0;
  }
  .about-me-content h4 {
    text-align: center;
  }

  .about-me-content p {
    text-align: center;
  }

  .services h4,
  .services h5 {
    text-align: center;
  }

  .questions h4,
  .questions h5 {
    text-align: center;
  }

  .ask {
    flex-direction: column-reverse;
  }
  .any-ask {
    flex-direction: column;
    margin-top: 20px;
  }

  .gallery {
    flex-direction: column-reverse;
    justify-content: flex-end;
  }
  .imgs img {
    width: 120px;
    height: 120px;
    margin: 5px;
  }

  .imgs-down,
  .imgs-up {
    min-height: 300px;
  }
  .gallery-content {
    padding: 0;
    align-items: center;
    width: 100%;
  }

  .gallery-content h4,
  .gallery-content p {
    text-align: center;
  }
  .gallery-content > .botton {
    display: none;
  }
  .btn-bottom {
    margin-top: 10px;
    display: flex;
  }

  .last-subject {
    flex-direction: column;
    align-items: center;
  }

  .last-subject-content h4,
  .last-subject-content p {
    text-align: center;
  }
  .last-subject-content > .botton{
    display: none;
  }
}
</style>
