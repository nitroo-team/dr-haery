
const routes = [
  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '', component: () => import('pages/homepage.vue') },
      { path: '/blog', component: () => import('pages/blog.vue') },
      { path: '/blog-1', component: () => import('pages/blog-1.vue') },
      { path: '/gallery', component: () => import('pages/gallery.vue') },
      { path: '/about-me', component: () => import('pages/aboutme.vue') },
      { path: '/FAQ', component: () => import('pages/FAQ.vue') },
    ]
  },
  {
    path: '*',
    component: () => import('pages/Error404.vue')
  }
]

export default routes;
