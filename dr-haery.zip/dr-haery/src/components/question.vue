<template>
  <div class="question-cards revers">
    <p class="m-0">{{ text }}</p>
    <img src="~assets/Icons/Path 159.svg" alt="Plus" />
  </div>
</template>
<script>
export default {
  name: "Question-cards",
  data() {
    return {};
  },
  props: {
    text: {
      type: String,
    },
  },
};
</script>
<style >
.question-cards {
  width: 100%;
  max-width: 700px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border: 2px solid var(--main-color-dark);
  border-radius: 50px;
  box-sizing: border-box;
  padding: 0 20px;
}
.question-cards > p {
  text-align: right;
}
.question-cards > img {
  width: 30px;
  height: auto;
}
@media only screen and (max-width: 760px) {
  .question-cards {
    border-radius: 20px;
    align-items: flex-start;
  }
}
</style>