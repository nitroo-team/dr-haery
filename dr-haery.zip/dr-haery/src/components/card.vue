<template>
  <router-link :to="link" tag="div" :class="['cards m-2', bg ? 'bg-color' : '']">
    <img :src="img" :alt="title" />
    <div class="cards-content">
      <div class="date-category revers">
        <p class="d-flex revers">
          <img class="ml-1" src="~assets/Icons/category.svg" alt="category" />
          {{ category }}
        </p>
        <p class="d-flex revers">
          <img
            class="ml-1"
            src="~assets/Icons/Icon material-access-time.svg"
            alt="category"
          />

          {{ date }}
        </p>
      </div>
      <h5>عنوان: {{ title }}</h5>
      <p>{{ text.substr(0, 150) }}</p>
    </div>
  </router-link>
</template>
<script>
export default {
  name: "Card",
  props: {
    bg: {
      type: Boolean,
      default: false,
    },
    img: {
      type: String,
    },
    category: {
      type: String,
      default: "دسته بندی",
    },
    date: {
      type: String,
      default: "۲۱ مرداد ۹۹",
    },
    title: {
      type: String,
      default: "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم",
    },
    text: {
      type: String,
      default:
        "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد",
    },
    link: {
      type: String,
      default: "#",
    },
  },
  data() {
    return {};
  },
};
</script>
<style>
.cards {
  min-width: 250px;
  max-width: 300px;
  width: 90%;
  height: 400px;
  border-radius: 20px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  background-color: #fff;
  box-shadow: 1px 10px 20px #666;
  color: #111;
  cursor: pointer;
}

.cards > img {
  width: 100%;
  height: auto;
  object-fit: cover;
  object-position: center;
  border-radius: 20px;
}
.cards-content {
  width: 100%;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: flex-end;
  box-sizing: border-box;
  padding: 5px 20px;
}
.date-category {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.cards-content > h5,
.cards-content > p {
  width: 100%;
  text-align: right;
}
.cards-content h5 {
  font-size: 1.2rem;
  font-weight: 400;
}

.bg-color {
  background-color: var(--main-color);
  box-shadow: 0px 5px 5px #666;
  color: var(--white);
}
</style>