<template>
  <div class="contact">
    <button class="close-btn">
      <img src="~assets/Icons/close button.svg" alt="X" />
    </button>
    <div class="questionaire-content">
      <div class="question-part-1">
        <input
          name="email"
          class="question-input"
          type="text"
          placeholder="ایمیل"
        />
        <input
          name="name"
          class="question-input"
          type="text"
          placeholder="نام"
        />
      </div>
      <textarea placeholder="سوال"></textarea>
      <button class="botton">ارسال سوال</button>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style>
.contact {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 90%;
  min-height: 350px;
  background-color: var(--main-color);
  display: flex;
  justify-content: space-evenly;
  align-items: center;
  box-sizing: border-box;
  padding: 30px;
  padding-top: 60px;
  border-radius: 10px;
  box-shadow: 0 5px 15px #555;
  overflow: hidden;
}

.close-btn {
  border: none;
  background: none;
  width: 50px;
  height: 50px;
  position: absolute;
  right: 5%;
  top: -5%;
  outline: none;
}

.questionaire-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  width: 80%;
  height: 100%;
}

.question-part-1 {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.question-input {
  width: 49%;
  border-radius: 20px;
  border: none;
  padding: 10px;
  padding-right: 20px;
  box-sizing: border-box;
  text-align: right;
  margin: 5px 0;
}

.questionaire-content > textarea {
  width: 100%;
  min-height: 250px;
  border-radius: 20px;
  flex-grow: 1;
  margin: 5px 0;
  padding: 10px;
  padding-right: 20px;
  box-sizing: border-box;
  text-align: right;
}

.botton {
  width: 150px;
  background-color: var(--main-color-dark);
  border: none;
  border-radius: 50px;
  padding: 5px 35px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: var(--white);
  white-space: nowrap;
}

@media only screen and (max-width: 760px) {
  .contact {
    padding: 60px 5px;
    top: 55%;
  }

  .questionaire-content {
    width: 100%;
  }
  .question-part-1 {
    flex-direction: column;
  }
  .question-input {
    width: 100%;
  }
  .questionaire-content > textarea {
    min-height: 200px;
  }
  .close-btn {
    right: 10%;
  }
}
</style>
