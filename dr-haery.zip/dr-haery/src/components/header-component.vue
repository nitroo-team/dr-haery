<template>
  <header v-if="!other" class="header-component">
    <img :src="img" :alt="title" />

    <div class="routes revers">
      <p class="m-0" v-for="(r, i) in routes" :key="i">
        <i class="fa fa-angle-left mb-1"></i>
        {{ r }}
      </p>
      <p class="m-0 mr-2 there-route">{{ title }}</p>
    </div>

    <div class="header-component-content">
      <h2 class="in-line m-0">{{ title }}</h2>
      <h5 class="m-0">{{ text }}</h5>
      <div class="search" v-if="search">
        <label for="search-id">
          <img src="~assets/Icons/Icon feather-search.svg" alt="Search" />
        </label>
        <input type="search" id="search-id" />
      </div>
    </div>
  </header>

  <header v-else class="header-component">
    <img :src="img" :alt="title" />

    <div class="routes revers">
      <p class="m-0" v-for="(r, i) in routes" :key="i">
        <i class="fa fa-angle-left mb-1"></i>
        {{ r }}
      </p>
      <p class="m-0 mr-2 there-route">...{{ title.substr(0, 15) }}</p>
    </div>

    <div class="search-t-l" v-if="search">
      <label for="search-id">
        <img src="~assets/Icons/Icon feather-search.svg" alt="Search" />
      </label>
      <input type="search" id="search-id" />
    </div>

    <div class="header-component-content other-content">
      <h2 class="title-header">{{ title }}</h2>
      <h5>{{ text }}</h5>
    </div>
  </header>
</template>

<script>
export default {
  name: "HeaderComponent",
  props: {
    img: {
      type: String,
    },
    title: {
      type: String,
    },
    text: {
      type: String,
    },
    search: {
      type: Boolean,
      default: true,
    },
    routes: {},
    other: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {};
  },
};
</script>

<style>
.in-line{
  white-space: nowrap;
}
.header-component {
  width: 100%;
  min-height: 400px;
  object-fit: cover;
  object-position: center;
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.header-component > img {
  object-fit: cover;
  object-position: center;
  width: 100%;
  min-width: 1100px;
  position: absolute;
  top: 0;
}
.header-component-content {
  z-index: 10;
  position: absolute;
  left: 50%;
  top: 60%;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.header-component-content h2,
.header-component-content h5 {
  width: 100%;
  text-align: center;
  color: var(--white);
}

.header-component-content .search {
  width: 110%;
  background-color: #fff;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  border-radius: 50px;
  box-sizing: border-box;
  padding: 5px 15px;
  border: 2px solid var(--main-color-dark);
}

.header-component-content .search > label,
.search-t-l > label {
  background-color: var(--main-color-dark);
  min-width: 30px;
  min-height: 30px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0;
  margin-right: 5px;
}
.header-component-content .search > input,
.search-t-l > input {
  width: 90%;
  flex-grow: 1;
  border: none;
  background: none;
  outline: none;
  height: 100%;
  font-size: 1.2rem;
  text-align: right;
  color: var(--main-color-dark);
}

.routes {
  position: absolute;
  top: 90px;
  right: 15%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--main-color-light);
  box-sizing: border-box;
  padding: 10px 15px;
  border-radius: 50px;
}
.routes p {
  white-space: nowrap;
}
.there-route {
  color: #777777;
}

.search-t-l {
  position: absolute;
  left: 15%;
  top: 90px;
  background-color: #fff;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  border-radius: 50px;
  box-sizing: border-box;
  padding: 3px 15px;
  border: 2px solid var(--main-color-dark);
  min-width: 200px;
}
.other-content {
  top: 70%;
}

@media only screen and (max-width: 880px) {
  .search-t-l {
    top: 135px;
  }
}

@media only screen and (max-width: 760px) {
  .header-component {
    min-height: 350px;
  }
  .header-component-content {
    top: 60%;
  }
  .other-content {
    top: 80%;
  }
  .header-component-content h2 {
    font-size: 2.2rem;
  }
  .header-component-content h5 {
    font-size: 1.2rem;
  }
  .header-component-content .search {
    width: 100%;
  }
  .routes {
    right: 10%;
    padding: 5px 10px;
  }
  .title-header {
    line-height: normal;
    width: 90%;
  }
  .search-t-l {
    width: 70%;
  }
}
</style>