<template>
  <div class="contact revers">
    <button class="close-btn">
      <img src="~assets/Icons/close button.svg" alt="X" />
    </button>
    <img src="~assets/Photos/map.png" alt="map" />
    <div class="contact-content">
      <div class="address-phone">
        <div class="text-content">
          <p>
            خیابان شهید طالقانی، خیابان هشت بهشت، نبش کوچه رز، پلاک ۷، طبقه دوم
          </p>
          <img
            src="~assets/Icons/Icon material-location-on.svg"
            alt="location"
          />
        </div>
        <div class="text-content">
          <p>۰۲۱۲۳۴۵۶۷۸</p>
          <img src="~assets/Icons/Icon awesome-phone-alt.svg" alt="phone" />
        </div>
      </div>
      <div class="social">
        <router-link to="#" tag="a">
          <img src="~assets/Icons/Path 3.svg" alt="instagram" />
        </router-link>
        <router-link to="#" tag="a">
          <img src="~assets/Icons/Path 98.svg" alt="twitter" />
        </router-link>
        <router-link to="#" tag="a">
          <img src="~assets/Icons/Path 1.svg" alt="facebook" />
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Contact",
  data() {
    return {};
  },
};
</script>

<style>
.contact {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 90%;
  min-height: 350px;
  background-color: var(--main-color);
  display: flex;
  justify-content: space-evenly;
  align-items: center;
  box-sizing: border-box;
  padding: 30px;
  padding-top: 60px;
  border-radius: 10px;
  box-shadow: 0 5px 15px #555;
  overflow: hidden;
}
.contact > img {
  min-width: 300px;
  width: 40%;
  height: auto;
  border-radius: 20px;
  margin-left: 10px;
}

.contact-content {
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
}
.address-phone {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.text-content {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
.text-content p {
  width: 100%;
  text-align: right;
  color: var(--white);
  white-space: nowrap;
  margin: 0;
}
.social {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
.social a {
  margin: 0 5px;
}

.close-btn {
  border: none;
  background: none;
  width: 50px;
  height: 50px;
  position: absolute;
  right: 5%;
  top: -5%;
  outline: none;
}

@media only screen and (max-width: 760px) {
  .contact {
    flex-direction: column;
    padding: 60px 10px;
    top: 55%;
  }

  .contact > img {
    min-width: 250px;
    width: 100%;
    max-width: 350px;
    margin: 0;
  }
  .contact-content {
    align-items: center;
  }
  .address-phone p {
    white-space: pre-wrap;
  }
  .close-btn {
    right: 10%;
  }
  .social {
    justify-content: center;
    margin-top: 50px;
  }
}
</style>