<template>
  <div class="contact image">
    <button class="close-btn">
      <img src="~assets/Icons/close button.svg" alt="X" />
    </button>
    <div class="image-content">
      <div class="slider">
        <button class="next-btn" @click="nextSlide()">
          <img src="~assets/Icons/Group 60.svg" alt="next" />
        </button>
        <button class="prev-btn" @click="pervSlide()">
          <img src="~assets/Icons/Group 60.svg" alt="next" />
        </button>
        <div class="slider-items box-p">
          <div
            v-for="(img, i) in imgs"
            :key="i"
            v-show="i === index"
            :class="['slider-item', 'main-slide']"
            @click="index = i"
          >
            <img :src="img" alt="img" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Image",
  props: {
    imgs: {
      type: [],
      default: [],
    },
  },
  data() {
    return {
      index: 0,
    };
  },
  methods: {
    counter(index, f, count = this.imgs.length) {
      index += f % count;
      if (index < 0) return count - 1;
      else if (index >= count) return index - count;
      return index;
    },
    nextSlide() {
      this.index = this.counter(this.index, +1);
    },
    pervSlide() {
      this.index = this.counter(this.index, -1);
    },
  },
};
</script>
<style>
.contact {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 90%;
  min-height: 350px;
  background-color: var(--main-color);
  display: flex;
  justify-content: space-evenly;
  align-items: center;
  box-sizing: border-box;
  padding: 30px;
  padding-top: 60px;
  border-radius: 10px;
  box-shadow: 0 5px 15px #555;
  overflow: hidden;
}
.image {
  background-color: #666;
}
.close-btn {
  border: none;
  background: none;
  width: 50px;
  height: 50px;
  position: absolute;
  right: 5%;
  top: -5%;
  outline: none;
}

.image-content {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.image-content > img {
  width: 50%;
  min-width: 200px;
  height: auto;
}

.image-content > button {
  color: var(--white);
}
.slider {
  width: 100%;
  min-height: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
}
.slider > button {
  position: absolute;
  top: 50%;
  border: none;
  background: none;
  outline: none;
}

.next-btn {
  /* right: -15%; */
  right: 0;
  transform: translateY(-50%);
}
.prev-btn {
  /* left: -15%; */
  left: 0;
  transform: translateY(-50%) rotateY(180deg);
}
.slider-items {
  flex-grow: 1;
  display: flex;
  justify-content: center;
  align-items: center;
}
.slider-item {
  width: 50%;
  max-width: 350px;
  height: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;
  border-radius: 10px;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  transition: 1s all ease-in-out;
}
.main-slide {
  left: 50%;
  transform: translate(-50%, -50%) scale(1.3);
  z-index: 10;
}

.slider-item > img {
  width: 100%;
  height: auto;
}
@media only screen and (max-width: 760px) {
  .contact {
    padding: 60px 5px;
    top: 55%;
  }

  .close-btn {
    right: 10%;
  }
}
</style>