<template>
  <main>
    <Header />
    <router-view></router-view>
    <Footer />
  </main>
</template>

<script>
import Header from "./header.vue";
import Footer from "./Footer.vue";

export default {
  name: "MainLayout",
  components: { Header, Footer },
  data() {
    return {};
  },
};
</script>
