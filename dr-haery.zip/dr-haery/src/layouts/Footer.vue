<template>
  <footer class="footer">
    <div class="div">
      <h4>دکتر هانیه حائری</h4>
      <p class="p">
        متخصص جراحی فک دهان صورت <br />
        فلوشیپ جراحی های داخلی با 8 سال سابقه کار <br />
        متخصص جراحی فک دهان صورت <br />
      </p>
    </div>
    <div class="add">
      <p class="addres">آدرس</p>
      <br />
      <p>
        <i class="fa fa-map-marker" aria-hidden="true" /> خیابان شهید
        طالقانی,خیابان هشت بهشت<br />
        نبش کوچه رز ,پلاک7 ,طبقه دوم
      </p>
      <p class="phone">تلفن</p>
      <p>
        <i class="fa fa-phone" aria-hidden="true" /> 0211114567<br />
        0211117658
      </p>
    </div>
    <div class="dr">
      <router-link to="/" tag="span">صفحه اصلی</router-link>
      <router-link to="/" tag="span"> درباره من</router-link>
      <router-link to="/" tag="span"> پرسش پاسخ</router-link>
      <router-link to="/" tag="span"> گالری</router-link>
      <router-link to="/blog" tag="span">مطالب دندان پزشکی</router-link>
    </div>
    <div class="icon">
      <i class="fa fa-facebook-f" aria-hidden="true" />
      <i class="fa fa-instagram"></i>
      <i class="fa fa-twitter"></i>
    </div>
  </footer>
</template>
<script>
export default {
  name: "Footer",
  data() {
    return {};
  },
};
</script>
<style scoped>
.footer {
  width: 100%;
  padding: 50px;
  display: flex;
  direction: rtl;
  justify-content: space-evenly;
  background-color: #a081cd;
}

.div {
  text-align: center;
  color: white;
}
.add {
  text-align: right;
  color: white;
}
.dr {
  color: white;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  text-align: right;
}
.dr > span{
    cursor: pointer;
  }
.icon {
  display: flex;
  align-items: flex-end;
  letter-spacing: 10px;
  color: white;
}
.addres {
  display: none;
  visibility: hidden;
}
.phone {
  visibility: hidden;
  display: none;
}

@media only screen and (max-width: 400px) {
  .footer {
    display: flex;
    flex-direction: column;
  }
  .add {
    text-align: center;
  }
  .dr {
    text-align: center;
    display: none;
  }
  
  .p {
    display: none;
  }
  .icon {
    justify-content: inherit;
  }
  .addres {
    display: contents;
    visibility: visible;
  }
  .phone {
    visibility: visible;
    display: contents;
  }
  .fa fa-map-marker {
    visibility: hidden;
  }
}
</style>