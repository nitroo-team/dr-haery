<template>
  <nav class="nav-show box-p" v-if="menu">
    <img src="~assets/Group_542.svg" alt="Logo" />
    <ul class="menu-show">
      <router-link to="/about-me" tag="li">درباره من</router-link>
      <router-link to="/" tag="li">پرسش و پاسخ</router-link>
      <router-link to="/" tag="li">گالری</router-link>
      <router-link to="/" tag="li">مطالب دندانپزشکی</router-link>
    </ul>
    <router-link to="/about-me" tag="button" class="botton">
      تماس با من
      <img
        class="ml-1"
        src="~assets/icons/icon awesome-phone-alt.svg"
        alt="phone"
      />
    </router-link>
  </nav>
  <nav :class="['nav-d-show', 'box-p', showMenu ? 'h-100' : '']" v-else>
    <img src="~assets/Group_542.svg" alt="Logo" />
    <button class="btn-menu ml-3" @click="showMenu = !showMenu">
      <i class="fa fa-bars"></i>
    </button>

    <section class="menu" v-if="showMenu">
      <div class="menu-content">
        <div class="logo">
          <!-- <img src="~assets/Group_542.svg" alt="Logo" /> -->
          <h6 class="logo-name">Dr Haniye Haeri</h6>
          <button class="btn-menu" @click="showMenu = !showMenu">
            <i class="fa fa-times"></i>
          </button>
        </div>
        <ul class="menu-show menu-column">
          <router-link to="/about-me" tag="li">درباره من</router-link>
          <router-link to="/" tag="li">پرسش و پاسخ</router-link>
          <router-link to="/" tag="li">گالری</router-link>
          <router-link to="/" tag="li">مطالب دندانپزشکی</router-link>
        </ul>
        <div class="btns mb-5">
          <router-link to="/about-me" tag="button" class="botton mb-3">
            تماس با من
            <img
              class="ml-2"
              src="~assets/icons/icon awesome-phone-alt.svg"
              alt="phone"
            />
          </router-link>
          <router-link to="/about-me" tag="button" class="botton botton-o">
            سوال از من
          </router-link>
        </div>
      </div>
    </section>
  </nav>
</template>

<script>
export default {
  name: "Header",
  data() {
    return {
      menu: true,
      showMenu: false,
    };
  },
  created() {
    this.changeMenu(window.innerWidth);
    window.onresize = (e) => {
      this.changeMenu(e.target.innerWidth);
    };
  },
  methods: {
    changeMenu(size) {
      if (size <= 760) this.menu = false;
      else this.menu = true;
    },
  },
};
</script>

<style>
nav {
  box-shadow: 0 5px 10px #eee;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  transition: 1s all;
  background-color: var(--white);
  z-index: 100;
}

.botton {
  width: 150px;
  background-color: var(--main-color-dark);
  border: none;
  border-radius: 50px;
  padding: 5px 35px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: var(--white);
  white-space: nowrap;
}
.botton-o {
  background: none;
  border: 2px solid var(--main-color-dark);
  color: var(--main-color-dark);
}

.revers {
  flex-direction: row-reverse;
}

.box-p {
  box-sizing: border-box;
  padding: 10px 50px;
}

.nav-show {
  display: flex;
  flex-direction: row-reverse;
  justify-content: space-evenly;
  align-items: center;
}

.menu-show {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: row-reverse;
  justify-content: center;
  align-items: center;
}
.menu-column {
  flex-direction: column;
  flex-grow: 0.5;
  justify-content: flex-start;
  align-items: flex-end;
  width: 100%;
}
.menu-show li {
  margin: 0 5px;
  white-space: nowrap;
  cursor: pointer;
  padding: 10px;
  box-sizing: border-box;
}

.menu-column li {
  margin: 0;
}

.nav-d-show {
  display: flex;
  justify-content: space-around;
  align-items: center;
  overflow: hidden;
}
.btn-menu {
  background: none;
  border: none;
  font-size: 25px;
  color: var(--main-color-dark);
}

.menu {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  background-color: var(--main-color);
  animation: r-t-l 1s ease-in-out both;
  overflow: hidden;
  display: flex;
  justify-content: flex-end;
  align-items: center;
}
.menu-content {
  min-width: 250px;
  width: 70%;
  height: 100%;
  background-color: var(--white);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
  padding: 10px 30px;
  animation: ltr 1s ease-in-out both;
}
.logo {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.logo-name {
  white-space: nowrap;
  margin: 0;
  color: var(--main-color-dark);
}

@keyframes ltr {
  0% {
    transform: translateX(100%);
  }
  100% {
    transform: translateX(0);
  }
}

@media only screen and (max-width: 760px) {
  .box-p {
    box-sizing: border-box;
    padding: 5px 20px;
  }
}
</style>